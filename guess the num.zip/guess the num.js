// Generate a random number between 1 and 100
const randomNumber = Math.floor(Math.random() * 100) + 1;

// Function to check if the guess is correct
function checkGuess(guess) {
    if (guess === randomNumber) {
        return "Congratulations! You guessed the correct number!";
    } else if (guess < randomNumber) {
        return "Too low. Try again!";
    } else {
        return "Too high. Try again!";
    }
}

// Main function to play the game
function guessNumberGame() {
    let guess;
    let attempts = 0;

    do {
        guess = parseInt(prompt("Guess a number between 1 and 100:"));

        if (isNaN(guess)) {
            alert("Please enter a valid number.");
        } else {
            attempts++;
            alert(checkGuess(guess));
        }
    } while (guess !== randomNumber);

    alert(`It took you ${attempts} attempts to guess the number.`);
}

// Start the game
guessNumberGame();



